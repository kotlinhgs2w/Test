# TG Clone — Telegram-style messenger (Android)
Сборка APK без Android Studio:
1. Создай репозиторий на GitHub, залей туда всё содержимое этой папки.
2. Вкладка Actions → Build APK → Run workflow (или просто push).
3. Через ~3 мин скачай tg-clone-apk из Artifacts внутри запуска → app-debug.apk.
Локально: открой папку в Android Studio → Build → Build APK(s).
